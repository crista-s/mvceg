package com.trainee.staticdb;

import java.util.HashMap;

import com.trainee.bean.TraineeBean;

public class StaticDb {
	static HashMap<Integer, TraineeBean> traineeMap = getTraineeMap();
	 
	static {
	if(traineeMap == null){
		traineeMap = new HashMap<Integer, TraineeBean>();
	 
		TraineeBean a = new TraineeBean(1,"Vishal","CS","Bangalore");
		TraineeBean b = new TraineeBean(1,"Crista","EC","Mumbai");
		TraineeBean c = new TraineeBean(1,"Shipla","ME","Pune");
		TraineeBean d = new TraineeBean(1,"Ammu","CS","Gujarat");
		
	 
	traineeMap.put(1, a);
	traineeMap.put(2, b);
	traineeMap.put(3, c);
	traineeMap.put(4, d);

	}
}
	 
	public static HashMap<Integer, TraineeBean> getTraineeMap(){
	return  traineeMap;
	 
	}
}

